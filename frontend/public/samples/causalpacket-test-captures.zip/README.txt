CausalPacket synthetic test captures
==================================
Open https://causal-packet.vercel.app/ in Live API mode.
The Sample Captures cards analyze the same bundled scenarios with one click.

To test upload: extract this ZIP, click Select capture file, and choose one .pcap.
Do not upload the ZIP itself. All captures use fictional addresses and were generated offline.

01_healthy.pcap: no significant supported findings.
02_service_failure.pcap: 12 TCP connection refusals; likely fault.
03_possible_scan.pcap: possible scanning; suspected activity.
04_gateway_transition.pcap: unresolved, then suspected after Apply sample inventory, then unresolved after approving the second MAC. Packet facts stay fixed.
05_mixed_scan_and_fault.pcap: separate scan and service fault.
06_dns_faults.pcap: DNS resolver errors.
07_truncated.pcap: intentionally damaged; partial analysis.
08_arp_healthy.pcap: normal ARP probes/announcement.
09_dns_healthy.pcap: normal DNS including negative answers.

A clean result does not certify network safety. Raw application payloads are omitted from reports. Hosted uploads reach the API server; keep sensitive captures local.
